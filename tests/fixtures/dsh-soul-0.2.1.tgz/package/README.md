# DSH Soul 0.2.1

为 DSH 增加有来源、可纠正的长期记忆，以及经过用户反馈验证的工作技能。**用记忆与方法改善上下文，不训练模型权重，不自动改写自身代码。**

让 DSH 更懂你，也更会做事。项目原名 DSH Learning，现统一以 **DSH Soul** 发布，包名为 `dsh-soul`。

0.2 重点：长技能按需读取、试用技能可发现、候选审核摘要、跨连接失效的检索缓存、合并待处理纠正，以及可解释的学习失败与用量统计。无需新增依赖或模型请求。

**0.2.1 修复新版 DSH 安装拦截**：验证后将兼容声明扩展为 `0.2.0-rc.2 || 0.2.1-rc.2`。旧的 Soul 0.2.0 包仍只声明旧版支持；使用 DSH 0.2.1-rc.2 时请下载 Soul 0.2.1，无需跳过兼容检查。此处 Soul 版本与 DSH 版本分别编号。

## 运行与安装

- Node.js **24+**，使用自带 `node:sqlite`；不需要 Python、GPU、npm 运行时依赖或独立数据库服务。
- 已针对 **DSH 0.2.0-rc.2 与 0.2.1-rc.2** 验证，`engines.dsh` 只列出这两个版本。其他宿主版本需适配验证，不建议跳过兼容检查。
- 标准 DSH bundle：`package.json → dsh.bundle.patch → cordis.patch.yml`，包含中英文展示元信息。

安装打包文件（替换为实际绝对路径）：

```powershell
dsh plugin --profile web add 'C:\Downloads\dsh-soul-0.2.1.tgz'
```

重启 DSH，输入 `/learn help`。开发时可在源码目录运行 `npm pack` 生成 TGZ。桌面版应使用其内置插件管理入口，不要用 npm CLI 管理保留的 desktop profile。

从 GitHub Releases 下载 `dsh-soul-0.2.1.tgz` 后按上方命令安装；目前不通过 npm registry 发布。

已安装 Soul 0.2.0 的用户可退出 DSH 后使用相同安装命令升级；无需卸载或删除记忆库。0.2.1 沿用 schema 2，未改动记忆数据格式。

卸载：`dsh plugin --profile web remove dsh-soul`。本地记忆库保留，不删除聊天数据。

如果此前安装过 `dsh-learning`，先退出 DSH，使用 `dsh plugin --profile web remove dsh-learning` 移除旧插件，再安装 `dsh-soul`，并将旧插件的自定义 patch ID 改为 `dsh-soul`。不要同时加载两者；命令仍为 `/learn`，默认存储目录保留原名以继续使用已有记忆与额度。

## 立即体验：无需额外模型调用

```text
/learn prefer --profile 先给结论，再解释必要细节
/learn remember 当前项目使用 Node 24，修复前先复现问题
/learn search 修复
/learn list active
/learn inbox
/learn show 记忆ID
/learn revise 记忆ID 新的内容
/learn forget 记忆ID
/learn status
```

`prefer` 默认是当前项目偏好；`--profile` 是同一个 DSH profile 的通用偏好。`remember` 默认记录项目事实，也支持 `--profile`，请仅用于确实需要跨项目共享的事实。

当前目录来自 DSH session.header.cwd，按规范化路径划分项目；没有工作目录时只在当前会话内可见。不会自动猜测多个子目录属于同一个 Git 项目。不同 profile 使用独立数据库；单 profile 目前面向单用户，不作为多租户服务。

普通对话中的纠正在开启后台学习后可以被提炼为**候选**；主模型也可以调用 `learning_propose` 提交候选。`/learn inbox` 分别列出最多 10 条候选和试用技能，附来源摘录、总数与下一步命令。使用 `/learn accept ID` 接受后才自动召回。自然语言候选不会未经确认就变成永久偏好；当前明确指令仍应立即由 DSH 遵循，不必等学习完成。对已有同文候选执行 `remember/prefer` 会立即确认原记录；技能仍需试用验证。

## 技能闭环

```text
/learn skill {"title":"排查测试失败","preconditions":["已有可复现故障"],"steps":["记录失败输出","定位根因","进行最小修改"],"checks":["相关测试通过","确认原问题已解决"],"counterexamples":["没有复现时先收集信息，不直接重写"]}
/learn accept 技能ID
/learn feedback 技能ID pass 本次按流程定位并解决了故障
```

技能从 candidate 进入 trial。**两个不同会话的人工通过反馈**才提升为 active；同一会话重复反馈不叠加。一条失败反馈即停用为 deprecated，修订产生新版本并重新验证。不同会话只是最低限度的去重，并不能证明两次任务真的独立，仍需真实使用结果。

有效和相关试用技能以短卡片提供：ID、状态、标题、部分适用条件。上下文和 `learning_search` 返回相同的有界卡片；标记 `partial` 的资料必须先用 `learning_get` 读取全文、检查项和反例后使用。试用技能明确标记为待检查方案，不当成已经验证的成功经验；候选和失败技能不自动注入。`/learn search` 仍查看有效记忆全文，`/learn show ID` 可人工检查任意当前范围记录。

插件不自动运行候选脚本，不自动重放具有外部副作用的工具，也不把普通工具 exit=0 当成整个任务成功。短卡片减少每次携带完整长技能的输入；真正使用时读取全文会增加一次工具往返及模型输入，不能保证每个任务都更快或总费用都更低。

## 可选：后台增量学习

默认 `learning: false`：本地采集、检索、明确记忆命令和技能管理均可用，**没有后台模型请求**。在插件配置中显式设置 DSH 已注册的 provider 与 model 后开启。不会隐式选择主对话的昂贵模型。

示例：在当前 profile 的 `cordis.patch.yml` 中追加以下宿主 patch（如已有同 ID override，请合并 config）。该结构需与所安装 DSH 的 patch 格式对应：

```yaml
- id: dsh-soul
  config:
    learning: true
    provider: your-registered-provider
    model: your-low-cost-model
    dailyCalls: 4
    maxOutputTokens: 600
    maxInputBytes: 12000
    memoryBytes: 2400
    idleMs: 30000
```

provider/model 必须是用户自己的 DSH 路由；不附带 API Key。`reasoningEffort` 可选，必须用适配器支持的值；当前 DeepSeek 宿主适配器使用 `off/low/high/max`，可将简单提炼设为 `off` 后测试质量。其他适配器不应直接套用该值。

触发条件是明确记忆/纠正类表达、工具失败和手动 `/learn review`。关键词只是排队信号，不是自动生效判断。它会把近期有限摘录交给学习模型；返回内容须引用本批证据、通过结构校验，然后保存为候选。普通对话不逐轮进行模型反思，也不整库重写。同一会话同一范围、尚未开始的作业在合并后不超过 24 条来源时合并；在途作业不修改。排队也会考虑最近 12 条常规消息之外尚未处理的纠正，仍受输入字节和队列上限约束。

后台只在观察到的会话空闲且达到 idleMs 后启动，一次处理一个作业。任务忙时不启动新作业，已发出的作业允许在限时内结束。冷启动后可能无法知道所有已在运行的宿主任务，不能保证全局资源调度。

## 费用、延迟与边界

- 每个 profile 每 UTC 日最多 4 个插件逻辑学习请求，额度跨重启持久化；失败、中断也占用一次。
- 不自动重试。超时或崩溃后用量可能未知，不自动重发，避免重复付费。
- 日额度是本插件调用限制，**不是供应商 HTTP 尝试数或人民币硬上限**。宿主/provider 中间件自身的重试需另外配置与计费。
- 单请求证据默认最多 12000 UTF-8 字节，输出上限 600 token。输入字节数不是精确 token 数；系统提示与请求封装另计。
- 动态记忆区块默认最多 2400 字节，完整卡片放不下时跳过，不产生半截 JSON。普通长记忆仅提供最多 500 字节预览，并标记需取全文。
- 使用中文二元词及英文关键词搜索，无嵌入 API；同义改写检索能力有限，不提供向量检索。
- 最多缓存 128 个范围/原查询/字节上限组合；增添、接受、修订、反馈、删除均通过数据库版本标记失效，其他连接的变更也可见。命中缓存只节省本地检索时间，主模型仍需阅读返回资料。
- `/learn status` 返回配置、原始 usage、当日已报告用量汇总、未知用量请求数、当前项目最近 10 个作业结果，以及缓存命中/未命中和合并次数。input/cacheRead/cacheWrite 分列，reasoning 只是输出内部统计，不能再叠加到 output 计费；可选字段没有报告时，汇总只表示已报告部分。状态不覆盖主对话总费用，也不自动换算货币。
- 失败原因使用固定代码：`timeout`、`interrupted`、`truncated`、`invalid_candidates`、`provider_failure`、`output_too_large`；不把供应商错误正文或无效模型输出写进诊断。`recentJobs` 中的 `source_changed` 表示证据已删除或修订。
- 检索计数先缓存在进程内，在查看状态、空闲维护或正常卸载时落盘，避免每次拼提示词写库；崩溃可能损失未刷新统计，但已预留的学习额度独立持久化。
- 稳定偏好也占主模型输入，每次请求可能再计费。本地存储免费不等于模型阅读记忆免费。

本地捕获只读取正文和有界错误摘要，不读取 reasoning 内容。常见凭据格式在落盘前脱敏，但模式匹配不能保证识别所有秘密；敏感内容不要交给自动学习。开启远程学习模型后，选中的摘录会经 DSH 发往该模型；不能称为全程离线。

## 数据、删除与可靠性

默认数据路径：`~/.dsh/dsh-learning/<profile>/memory.sqlite`，为兼容更名前的数据特意保留 `dsh-learning` 目录名，尊重 `DSH_HOME`。安装目录位于 profiles 下时自动识别 profile；直接从源码加载时默认为 development，也可显式配置 profile/database。指定同一个 database 会共享存储，勿用于需要隔离的 profile。

升级时先正常退出使用该库的 DSH，备份数据库，再安装 0.2。首次加载在事务内将 schema 1 升为 2，保留记忆、来源、反馈、遗忘指纹和已用额度；不进行模型重提炼。0.1 无法打开升级后的库，回退应恢复升级前备份；不应让两个插件版本同时写同一库。

每条记忆保留来源、范围、状态和版本。原文属于数据，不拥有修改身份或权限的权力；用户当前要求优先。工具只能读或提交候选，激活/修订/删除由 `/learn` 人类命令执行。

遗忘会删除记录、搜索条目、引用摘录及依赖或共享来源的记忆，并阻止相同来源事件和相同文字指纹被自动重新学习。用户可以通过新的明确 remember/prefer 命令重新记住同一事实，旧来源仍受抑制。为了稳妥，部分共享证据的关联记忆也会一起删除；后台在途结果检查版本变化，不能将已删除来源写回。

删除不能清除宿主原聊天记录、已经发送给 API 的内容或已在当前模型历史中的副本；需要时新建会话并按宿主方式删除历史。此版本也不保证识别来自全新来源的同义重述。SQLite secure_delete 已开启，但不承诺对磁盘备份、WAL 和文件系统快照进行取证级擦除。

未引用对话摘录默认 30 天保留、约 10000 条上限；已被记忆引用的来源保留。维护在空闲时运行，因此不是即时磁盘硬上限。未完成队列最多 32 个，过期作业不重发；有效与候选记忆合计上限 10000，达到后需整理。完成作业与调用明细保留 30 天。遗忘抑制指纹不含原文，长期保留用于防复活。

## 验证

```powershell
npm test
npm run eval
npm run bench
npm pack --dry-run
```

测试涵盖中文检索、范围隔离、候选状态、技能反馈、删除与修订传播、在途删除、额度并发与重启、超时与关闭、来源伪造、隐藏思维隔离，以及真实 DSH SessionStore/CommandRuntime/SystemPrompt、ToolRuntime、LlmRuntime 和兼容检查器。LLM 测试使用真实宿主服务与本地确定性适配器，不请求付费 API。

设置 `DSH_TEST_PACKAGE` 可指向另一位置的宿主 package.json，`DSH_TEST_VERSION` 可断言版本；显式指定的宿主缺失时测试失败，不能静默跳过。默认未安装宿主时集成测试明确跳过。CI 额外安装两个已支持宿主，在 Windows/Linux 上运行包含宿主集成的完整检查。详见 `docs/COMPATIBILITY-0.2.1.md`。

性能脚本创建独立临时 SQLite 库，用 10000 条合成记录测检索 p50/p95，分别报告插件缓存未命中和预热后的命中；未清空操作系统及 SQLite 缓存。`npm run eval` 是 11 个手工编写的用户历史检索场景，包括项目隔离、偏好确认、修订、遗忘和长技能生命周期；不是公开独立测试集，不衡量主模型是否真正完成任务。真实 API 语义质量、总费用与跨设备性能仍需后续评测。

## 设计依据

借鉴 Reflexion 的反馈学习、ACE 的增量经验维护、Mem0 的选择性记忆和 Sleep-time Compute 的异步复用思想。本实现独立编写，没有复制这些项目源码，也不声称复现其论文指标。

暂未实现：向量检索、图形记忆面板、全自动技能测试/执行、模型微调、自主源码修改、人民币硬预算、自动修改身份与目标。
